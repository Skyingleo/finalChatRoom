//setInterval(run, 2000);
const socket = io();
const chatTitle = document.getElementById("chatTitle");
const Uname = document.getElementById("Uname");
const speak = document.getElementById("speak");
const cTree = document.getElementsByClassName("body-bg");

socket.on("connect", () => {
  console.log(socket.id); // x8WIv7-mJelg7on_ALbx
});

setInterval(function (){
	$.get("/background", function(value){
		//console.log("heyo!");
		if (value == "1") {
			$ ("body").css("background-color", "#989898");
			chatTitle.style.color = "black";
			Uname.style.color = "black";
			speak.style.color = "black";
			cTree.style.display = 'none';
		}
		else {
			$ ("body").css("background-color", "black");
			chatTitle.style.color = "white";
			Uname.style.color = "red";
			speak.style.color = "green";
		}
	})
}, 2000);

$ ("#Enter").click(function(){
	console.log('message', $('#Name').val() + ": " + $('#Text').val());
	// if($('Name'.val()) == ""){
	// 	socket.emit('message', "nobody" + ": " + $('#Text').val());
	// }
	// else{
	// 	socket.emit('message', $('#Name').val() + ": " + $('#Text').val());
	// }
	socket.emit('message', $('#Name').val() + ": " + $('#Text').val());

})

$ ("#button1").click(function(){
	$.get("/change");
})

socket.on('count', function (data) {
  $('.user-count').html(data);
});

// When we receive a message``
// it will be like { user: 'username', message: 'text' }
socket.on('textline', function (data) {
	console.log(data);
  	$('ul').append("<li>"+data+'</li>');
});

socket.on('texthistory', function (data) {
	console.log(data);
	for (let i = 0; i < data.length; i++){
	  	$('ul').append("<li>"+data[i]+'</li>');
	}
});
//<script.src = "/socket.io/socket.io.js"></script>